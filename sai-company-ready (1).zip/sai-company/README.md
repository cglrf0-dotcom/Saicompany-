# SAI Company

Landing page + AI platform UI for saicompany.app.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Routes

- `/` — public landing page
- `/platform` — SAI platform dashboard concept

## Deploy

Push this folder to GitHub and import the repository into Vercel. Then connect `saicompany.app` as the production domain.
