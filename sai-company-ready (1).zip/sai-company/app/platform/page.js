import Link from "next/link";

const stats = [["AI RUNS", "1,284"], ["AUTOMATIONS", "47"], ["TIME SAVED", "126h"], ["SIGNALS", "98.4%"]];

export default function Platform() {
  return (
    <main className="app-shell">
      <aside className="sidebar">
        <Link href="/" className="brand"><span className="brand-mark">S</span> SAI</Link>
        <div className="side-label">WORKSPACE</div>
        <nav>
          <a className="active">Overview</a><a>AI Workspace</a><a>Automations</a><a>Insights</a>
        </nav>
        <div className="side-bottom"><span className="status-dot"/> Systems operational</div>
      </aside>
      <section className="dashboard">
        <header className="dash-header">
          <div><div className="kicker">MONDAY · SEPTEMBER 21, 2026</div><h1>Good morning.</h1></div>
          <Link href="/" className="back">← Website</Link>
        </header>
        <div className="stats">{stats.map(([k,v]) => <div className="stat" key={k}><small>{k}</small><strong>{v}</strong><span>↑ 12.8%</span></div>)}</div>
        <div className="dash-grid">
          <section className="panel large">
            <div className="panel-head"><div><small>AI ACTIVITY</small><h2>Intelligence flow</h2></div><span className="live"><i/> LIVE</span></div>
            <div className="graph"><div className="line" /><div className="graph-labels"><span>08:00</span><span>12:00</span><span>16:00</span><span>20:00</span></div></div>
          </section>
          <section className="panel">
            <div className="panel-head"><div><small>AI AGENT</small><h2>Ask SAI</h2></div></div>
            <div className="agent">
              <div className="agent-avatar">S</div>
              <p>Ready to analyze your workspace. What should we work on?</p>
              <div className="prompt">Summarize today’s activity <span>→</span></div>
            </div>
          </section>
        </div>
      </section>
    </main>
  );
}