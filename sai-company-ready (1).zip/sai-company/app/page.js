import Link from "next/link";

const features = [
  ["01", "AI Workspace", "Un espacio inteligente para convertir información en decisiones y acciones."],
  ["02", "Automation", "Diseña flujos que ejecutan tareas repetitivas sin perder control."],
  ["03", "Intelligence", "Obtén señales, resúmenes y recomendaciones desde tus datos."],
];

export default function Home() {
  return (
    <main>
      <nav className="nav shell">
        <Link href="/" className="brand"><span className="brand-mark">S</span> SAI<span className="muted">COMPANY</span></Link>
        <div className="nav-links">
          <a href="#platform">Platform</a>
          <a href="#solutions">Solutions</a>
          <a href="#contact">Contact</a>
        </div>
        <Link href="/platform" className="nav-cta">Open Platform ↗</Link>
      </nav>

      <section className="hero shell">
        <div className="eyebrow"><span className="pulse" /> SOFTWARE INTELLIGENCE / 01</div>
        <h1>Build faster.<br /><em>Think smarter.</em></h1>
        <p className="hero-copy">
          SAI is intelligent software for teams that want to automate work,
          understand their data, and move from idea to execution.
        </p>
        <div className="actions">
          <Link href="/platform" className="button primary">Explore SAI <span>→</span></Link>
          <a href="#platform" className="button ghost">See how it works</a>
        </div>
        <div className="hero-orbit" aria-hidden="true">
          <div className="orbit o1"></div><div className="orbit o2"></div>
          <div className="core"><span>SAI</span><small>INTELLIGENCE</small></div>
        </div>
      </section>

      <section id="platform" className="section shell">
        <div className="section-label">THE PLATFORM</div>
        <div className="section-head">
          <h2>One intelligence layer.<br /><span>Many possibilities.</span></h2>
          <p>Designed as a foundation for modern AI products, workflows and business systems.</p>
        </div>
        <div className="feature-grid">
          {features.map(([n, title, text]) => (
            <article className="feature" key={n}>
              <div className="feature-num">{n}</div>
              <h3>{title}</h3>
              <p>{text}</p>
              <span className="arrow">↗</span>
            </article>
          ))}
        </div>
      </section>

      <section id="solutions" className="statement">
        <div className="shell statement-inner">
          <div className="section-label">BUILT FOR WHAT’S NEXT</div>
          <h2>Less busywork.<br /><span>More intelligence.</span></h2>
          <p>SAI brings AI closer to the work that matters — with a product experience that stays simple, fast and human.</p>
        </div>
      </section>

      <footer id="contact" className="footer shell">
        <div><span className="brand-mark">S</span> SAI COMPANY</div>
        <div className="footer-note">Software intelligence for the next generation.</div>
        <div>© 2026 SAI Company</div>
      </footer>
    </main>
  );
}