import "./globals.css";

export const metadata = {
  title: "SAI Company — Software Intelligence",
  description: "AI software built for teams that move faster.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}